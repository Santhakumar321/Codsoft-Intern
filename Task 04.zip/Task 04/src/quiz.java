import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class quiz {
    static int score = 0;
    static int questionIndex = 0;
    static int timePerQuestion = 10; // seconds per question
    static boolean timeUp = false;

    public static void main(String[] args) {
        String[] questions = {
                "What is the capital of France?",
                "Which planet is known as the Red Planet?",
                "What is the largest mammal?",
                "Which language is primarily used for Android development?",
                "Who wrote 'To Kill a Mockingbird'?"
        };

        String[][] options = {
                {"1. Paris", "2. London", "3. Rome", "4. Berlin"},
                {"1. Earth", "2. Mars", "3. Jupiter", "4. Venus"},
                {"1. Elephant", "2. Whale", "3. Shark", "4. Giraffe"},
                {"1. Java", "2. Python", "3. Swift", "4. C++"},
                {"1. Harper Lee", "2. J.K. Rowling", "3. Ernest Hemingway", "4. Mark Twain"}
        };

        int[] correctAnswers = {1, 2, 2, 1, 1};

        Scanner scanner = new Scanner(System.in);

        for (questionIndex = 0; questionIndex < questions.length; questionIndex++) {
            timeUp = false;
            Timer timer = new Timer();
            TimerTask task = new TimerTask() {
                public void run() {
                    timeUp = true;
                    System.out.println("\nTime's up!");
                    timer.cancel();
                }
            };

            timer.schedule(task, timePerQuestion * 1000);

            System.out.println("Question " + (questionIndex + 1) + ": " + questions[questionIndex]);
            for (String option : options[questionIndex]) {
                System.out.println(option);
            }

            int userAnswer = -1;
            while (!timeUp && userAnswer == -1) {
                if (scanner.hasNextInt()) {
                    userAnswer = scanner.nextInt();
                    if (userAnswer < 1 || userAnswer > 4) {
                        System.out.println("Invalid option. Please choose a number between 1 and 4.");
                        userAnswer = -1;
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); // clear invalid input
                }
            }

            if (!timeUp) {
                if (userAnswer == correctAnswers[questionIndex]) {
                    score++;
                }
                timer.cancel(); // stop the timer if answer is submitted before time is up
            }

            System.out.println(); // Print a new line for readability
        }

        // Show final results
        System.out.println("Quiz completed!");
        System.out.println("Your final score is: " + score + "/" + questions.length);

        // Summary of correct/incorrect answers
        for (int i = 0; i < questions.length; i++) {
            String result = (correctAnswers[i] == correctAnswers[i]) ? "Correct" : "Incorrect";
            System.out.println("Question " + (i + 1) + ": " + result);
        }

        scanner.close();
    }
}

